
public class m {

	public static void main(String[] args) {
		

	}

}
