
public class person {
	
	int id, mob;
	String name,fname,org;
	
	person(int id, String name, String fname, String org, int mob){
		this.id = id;
		this.name = name;
		this.fname = fname;
		this.org = org;
		this.mob = mob;
	}
	
}
