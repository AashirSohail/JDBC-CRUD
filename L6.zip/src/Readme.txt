A program to connect to database where user can add different record, update delete and see

