import java.sql.Connection;

public class handler {
	
	static handler() {
		
		Connection connection = connect.make(url, username, password)
		
	}

	static void save(Person p) {
		
		
	} 
	
}
